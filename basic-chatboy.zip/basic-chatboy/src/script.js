const chatBox = document.getElementById('chat-box');
const userInput = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');

// Load previous messages from local storage
const loadMessages = () => {
    const messages = JSON.parse(localStorage.getItem('chatMessages')) || [];
    messages.forEach(msg => {
        displayMessage(msg.text, msg.sender);
    });
};

// Display message in chat box
const displayMessage = (text, sender) => {
    const messageDiv = document.createElement('div');
    messageDiv.className = sender;
    messageDiv.textContent = text;
    chatBox.appendChild(messageDiv);
    chatBox.scrollTop = chatBox.scrollHeight; // Scroll to the bottom
};

// Simple AI response logic
const getBotResponse = (userMessage) => {
    const lowerMessage = userMessage.toLowerCase();
    if (lowerMessage.includes('hello')) {
        return "Hi there! How can I help you today?";
    } else if (lowerMessage.includes('how are you')) {
        return "I'm just a bunch of code, but thanks for asking!";
    } else if (lowerMessage.includes('easter egg')) {
        return "You've found an easter egg! 🎉 Did you know that the first computer programmer was Ada Lovelace?";
    } else {
        return "I'm not sure how to respond to that.";
    }
};

// Save messages to local storage
const saveMessage = (text, sender) => {
    const messages = JSON.parse(localStorage.getItem('chatMessages')) || [];
    messages.push({ text, sender });
    localStorage.setItem('chatMessages', JSON.stringify(messages));
};

// Handle send button click
sendBtn.addEventListener('click', () => {
    const userMessage = userInput.value.trim();
    if (userMessage) {
        displayMessage(userMessage, 'user');
        saveMessage(userMessage, 'user');
        userInput.value = '';

        const botResponse = getBotResponse(userMessage);
        displayMessage(botResponse, 'bot');
        saveMessage(botResponse, 'bot');
    }
});

// Load messages on page load
window.onload = loadMessages;